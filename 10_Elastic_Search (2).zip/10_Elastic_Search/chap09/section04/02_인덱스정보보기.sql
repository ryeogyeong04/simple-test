-- 예제) 부서 인덱스 매핑 정보를 봅시다.
-- TODO: 테이블(인덱스), 컬럼(필드), 스키마(매핑)
-- TODO: 스키마: 테이블 설계(컬럼, 자료형)
-- TODO: GET /인덱스/__mapping
GET /department/_mapping