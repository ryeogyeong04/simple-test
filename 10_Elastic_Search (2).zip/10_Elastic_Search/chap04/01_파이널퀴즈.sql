-- 1) 사원 테이블에서 JOB이(직위) 'MANAGER' 인 사원의 데이터를 뽑아서
-- ENAME(사원명)으로 오름차순 정렬하세요
-- TODO: 정확한 조건조회: query - term(글자) - 필드.keyword
-- select * from employee
-- order by ename asc
POST /employee/_search
{
  "query": {
    "term": {
      "job.keyword": {
        "value": "MANAGER"
      }
    }
  },
  "sort": [
    {
      "ename.keyword": {
        "order": "asc"
      }
    }
  ]
}

-- 2) 사원테이블에서 JOB 이 'CLERK' 인 사원의 데이터를 뽑아서
-- ENAME(사원명)으로 내림차순 정렬하세요
-- select * from employee
-- where job='CLERK'
-- order by ename desc

POST /employee/_search
{
  "query": {
    "term": {
      "job.keyword": {
        "value": "CLERK"
      }
    }
  },
  "sort": [
    {
      "ename.keyword": {
        "order": "desc"
      }
    }
  ]
}

