-- 퀴즈 1) ALLEN 사원을 조회하세요, 단 match_phrase(전문 검색, 자연어검색)을 이용하세요
-- employee
-- select * from employee
-- where ename='ALLEN'
POST /employee/_search
{
  "query": {
    "match_phrase": {
      "ename": "ALLEN"
    }
  }
}

-- 퀴즈 2) job 이 "SALESMAN" 인 사원을 조회하세요, 단 match_phrase(전문 검색, 자연어
-- 검색)을 이용하세요
-- employee
-- select * from employee
-- where job='SALESMAN'
POST /employee/_search
{
  "query": {
    "match_phrase": {
      "job": "SALESMAN"
    }
  }
}

-- 퀴즈 3) dname 이 "SALES" 인 부서를 조회하세요, 단 match_phrase(전문 검색, 자연어검
-- 색)을 이용하세요
-- department
-- select * from department
-- where dname='SALES'
POST /department/_search
{
  "query": {
    "match_phrase": {
      "dname": "SALES"
    }
  }
}