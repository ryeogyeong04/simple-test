3. 아래 문항을 코딩하세요 지시된 사항외에 나머지는 자유롭게 하세요 
3-1) 부서별 급여 합계 구합니다.(group by dno) 위에서 구한 부서별 급여합계를 모두 더한 총합도 구합니다. 파이프라인 형제 집계를 사용하세요 

GET emp/_search
{
  "size": 0,
  "aggs": {
    "dept_salary_sum": {
      "terms": {
        "field": "dno"
      },
      "aggs": {
        "salary_sum": {
          "sum": {
            "field": "sal"
          }
        }
      }
    },
    "total_salary_sum": {
      "sum_bucket": {
        "buckets_path": "dept_salary_sum>salary_sum"
      }
    }
  }
}

3-2) QNA 오라클 테이블을 그대로 복제해서 ElasticSearch에 인덱스로 만드는 로그시태쉬 conf 파일을 작성하세요 
input {
  jdbc {
    jdbc_driver_library => "C:/logstash/lib/ojdbc8.jar"
    jdbc_driver_class   => "Java::oracle.jdbc.driver.OracleDriver"
    jdbc_connection_string => "jdbc:oracle:thin:@localhost:1521:xe"
    jdbc_user => "scott"
    jdbc_password => "tiger"
    statement => "SELECT * FROM QNA"
    schedule => "* * * * *"   # 1분마다 실행
  }
}

filter {
}

output {
  elasticsearch {
    hosts => ["http://localhost:9200"]
    index => "qna_index"
    document_id => "%{qna_id}"   # PK 컬럼명에 맞게 수정
  }
  stdout { codec => json_lines }
}


3-3) FAQ 오라클 테이블을 그대로 복제해서 ElaticSearch에 인덱스로 만드는 로그스태쉬 conf 파일을 작성하세요
input {
  jdbc {
    jdbc_driver_library => "C:/logstash/lib/ojdbc8.jar"
    jdbc_driver_class   => "Java::oracle.jdbc.driver.OracleDriver"
    jdbc_connection_string => "jdbc:oracle:thin:@localhost:1521:xe"
    jdbc_user => "scott"
    jdbc_password => "tiger"
    statement => "SELECT * FROM QNA"
    schedule => "* * * * *"   # 1분마다 실행
  }
}

filter {
}

output {
  elasticsearch {
    hosts => ["http://localhost:9200"]
    index => "qna_index"
    document_id => "%{qna_id}"   # PK 컬럼명에 맞게 수정
  }
  stdout { codec => json_lines }
}
