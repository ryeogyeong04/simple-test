-- 1) 부서번호(DNO)가 20 및 30에 속한(=) (이거나,또는 OR, IN)
-- 사원의 이름(ENAME)과 부서번호(DNO)를 출력하되 
-- 이름을 기준으로 내림차순 출력하세요(정렬)
-- select ename, dno from employee
-- where dno in (20,30)
-- order by ename desc
-- TODO: query - terms
-- TODO: sort
-- TODO: term(=), range(>,<), terms(= 여러개)
-- TODO: 정렬, 집계: keyword 필드만 가능
POST /employee/_search
{
  "_source": ["ename", "dno"], 
  "query": {
    "terms": {
      "dno": [
        20,
        30
      ]
    }
  },
  "sort": [
    {
      "ename.keyword": {
        "order": "desc"
      }
    }
  ]
}