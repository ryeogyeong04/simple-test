package com.simplecoding.simpledms.qno.dto;

import java.time.LocalDateTime;

public class QnaDto {
    private Long qnaId;
    private String title;
    private String writer;
    private LocalDateTime regDate;

    // Constructor
    public QnaDto(Long qnaId, String title, String writer, LocalDateTime regDate) {
        this.qnaId = qnaId;
        this.title = title;
        this.writer = writer;
        this.regDate = regDate;
    }

    // Getters
    public Long getQnaId() { return qnaId; }
    public String getTitle() { return title; }
    public String getWriter() { return writer; }
    public LocalDateTime getRegDate() { return regDate; }
}
