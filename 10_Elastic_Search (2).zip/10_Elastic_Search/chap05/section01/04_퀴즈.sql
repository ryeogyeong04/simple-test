-- 퀴즈) 부서번호(dno)의 종류가 몇 개인지 출력하기
-- TODO: aggs - 별명 - cardinality - field: 글자.keyword
-- TODO: 인덱스명: employee
-- 키워드검색: 글자만(숫자 안됨)
POST /employee/_search
{
  "size": 0,
  "aggs": {
    "ddno": {
      "cardinality": {
        "field": "dno"
      }
    }
  }
}