-- 퀴즈) 부서 번호별(DNO) , 직위(job) 평균 급여를 화면에 표시하세요
-- 단, 부서번호를 내림차순 정렬하세요 (asc, desc)
-- select avg(salary) from employee
-- group by dno, job
-- order by dno desc
-- TODO: (응용)    : aggs - 별명 - terms
-- TODO:                         - aggs - 별명2 - terms
-- TODO;                                         - aggs - 별명3 - avg
POST /employee/_search
{
  "size": 0,
  "aggs": {
    "gdno": {
      "terms": {
        "field": "dno", "order": {
          "_key": "desc"
        }
      },
      "aggs": {
        "tsalary": {
          "terms": {
            "field": "job.keyword"
          }, 
          "aggs": {
            "tsalary2": {
              "avg": {
                "field": "salary"
              }
            }
          }
        }
      }
    }
  }
}




