-- 1) 퀴즈) 부서번호가(DNO) 10 이거나 20 인 사원들 화면에 표시하세요
-- select * from employee
-- where dno in (10,20)
-- 정확한 조회 3개(or): query - terms - 필드:[값,값2,...]

POST /employee/_search
{
  "query": {
    "terms": {
      "dno": [
        10,
        20
      ]
    }
  }
}


-- 2) 퀴즈) 부서번호가(DNO) 10 과  20 이 아닌 사원들 화면에 표시하세요
-- select * from employee
-- where dno not in (10,20)
-- not : query - bool - must_not- terms
POST /employee/_search
{
  "query": {
    "bool": {
      "must_not": [
        {
          "terms": {
            "dno": [
              10,
              20
            ]
          }
        }
      ]
    }
  }
}