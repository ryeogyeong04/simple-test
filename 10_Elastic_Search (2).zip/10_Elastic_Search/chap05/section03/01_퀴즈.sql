-- 퀴즈) 직위별(JOB) 평균 급여를 화면에 표시하세요
-- TODO: (응용)    : aggs - 별명 - terms
-- TODO:                         - aggs - 별명 - avg
-- select job, avg(salary) from employee group by job

POST /employee/_search
{
  "size": 0,
  "aggs": {
    "gjob": {
     "terms": {
       "field": "job.keyword"
     },
     "aggs": {
       "tavg": {
         "avg": {
           "field": "salary"
         }
       }
     }
    }
  }
}