-- 퀴즈
-- 1)
POST /employee/_search
{
  "query": {
    "match_all": {}
  }
}
-- 2)
POST /employee/_search
{
  "_source": ["eno", "ename"], 
  "query": {
    "match_all": {}
  }
}
