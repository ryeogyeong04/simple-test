-- 퀴즈 1) 부서테이블에서 DNO(부서번호) 가 20보다 큰 부서만 표시하세요
POST /department/_search
{
  "_source": ["dno","dname","loc"], 
  "query": {
    "range": {
      "dno": {
        "gt": 20
      }
    }
  }
}
-- 2) 급여가(SALARY) 1000 과 1500 사이의 사원 조회하기
POST /employee/_search
{
  "query": {
    "range": {
      "salary": {
        "gte": 1000,
        "lte": 1500
      }
    }
  }
}
-- 3) 사원 테이블에서 DNO(부서번호) 10 인 사원을 찾아 전체 출력하세요
-- "_source": ["*"], (생략가능: 전체컬럼 의미)
POST /employee/_search
{
  "_source": ["*"], 
  "query": {
    "term": {
      "dno": {
        "value": 10
      }
    }
  }
}
-- 4) 사원테이블에서 월급이 5000 인 사람의 이름을 출력하세요
POST /employee/_search
{
  "_source": ["ename"], 
  "query": {
    "term": {
      "salary": {
        "value": 5000
      }
    }
  }
}