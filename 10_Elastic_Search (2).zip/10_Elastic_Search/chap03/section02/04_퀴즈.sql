-- 퀴즈) 사원 테이블에서(EMPLOYEE) 사원명으로(ENAME) 오름차순 정렬하세요
-- 단, 필드.keyword 로 정렬하세요
-- select * from employee
-- order by ename asc
POST /employee/_search
{
  "query": {
    "match_all": {}
  },
  "sort": [
    {
      "ename.keyword": {
        "order": "asc"
      }
    }
  ]
}

-- 퀴즈) 사원 테이블에서(EMPLOYEE) 사원명으로(ENAME) 내림차순 정렬하세요
-- select * from employee
-- order by ename desc
POST /employee/_search
{
  "query": {
    "match_all": {}
  },
  "sort": [
    {
      "ename.keyword": {
        "order": "desc"
      }
    }
  ]
}

-- 퀴즈) 사원테이블에서(EMPLOYEE) 정렬하세요
-- 단, _score(유사도점수) 로 내림차순하고 사원명에 대해(ENAME) 추가로 오름차순으로 
-- 정렬하세요
-- select * from employee
-- order by ename desc, salary asc

POST /employee/_search
{
  "query": {
    "match_all": {}
  },
  "sort": [
    {
      "_score": {
        "order": "desc"
      },
      "ename.keyword": {
        "order": "asc"
      }
    }
  ]
}