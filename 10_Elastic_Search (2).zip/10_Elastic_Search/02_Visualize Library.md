# 다양한 차트 보기
# 02_Visualize Library.md
# 햄버거메뉴 - Visualize Library 메뉴 클릭
# Create new visualization 클릭
# Aggregation Based -> Vertical Bar 클릭(막대 그래프)
# 예제 1)
#   1) x-axis:
#      - Aggregation: Histogram
#      - Field      : salary
#   2) y-axis: 그대로(기본: count)
#      - Aggregation: count
#  Update 버튼 클릭 -> 차트 나옴