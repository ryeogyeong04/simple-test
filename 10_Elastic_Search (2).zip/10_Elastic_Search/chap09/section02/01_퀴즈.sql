-- 퀴즈1) emp 에 데이터를 추가하세요
-- 단, 문서번호는 랜덤 생성하세요
-- 사용법:
-- POST /인덱스/_doc
-- {
--   "필드명": 값,
--   "필드명2": "값2",
--   ...
-- }
POST /emp/_doc/
{
  "eno": 8000,
  "ename": "SMITH",
  "insert_time": "2025-07-30T00:00:00",
  "update_time": null
}


-- 2)  emp 에 데이터를 추가하세요
-- 단, 문서번호는 8000으로 생성하세요
-- PUT /인덱스/_doc/기본키(문서번호)
-- {
--   "필드": 값,
--   "필드2": "값2",
--   ...
-- }
-- TODO: GET(조회), POST(추가), PUT(수정), DELETE(삭제) : REST API(용어), 파이썬웹서비스(Flask)
-- 
PUT /emp/_doc/8001
{
  "eno": 8001,
  "ename": "홍길동",
  "insert_time": "2025-07-30T00:00:00",
  "update_time": null
}