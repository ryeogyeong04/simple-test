-- 퀴즈) 급여가(SALARY) 1000 과 4000 사이의 사원 조회하고 페이징하세요
-- 단, from(0), size(3) 사용하세요 
-- select * from employee
-- where salary between 1000 and 4000
-- TODO: query - range

POST /employee/_search
{
  "from": 0,
  "size": 3, 
  "query": {
    "range": {
      "salary": {
        "gte": 1000,
        "lte": 4000
      }
    }
  }
}