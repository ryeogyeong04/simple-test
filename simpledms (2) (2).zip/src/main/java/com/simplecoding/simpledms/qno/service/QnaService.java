package com.simplecoding.simpledms.qno.service;

import com.simplecoding.simpledms.qno.dto.QnaDto;

import java.util.List;

public class QnaService {
    List<QnaDto> getAllQnas();
}
