-- 퀴즈) 부서 번호가(DNO) 20이거나 직급이(JOB) 'MANAGER' 인 사원만 표시하세요
-- select * from employee
-- where dno=20
-- or job='MANAGER'
-- TODO: 힌트) query - bool - should(or) - term(term 필드.keyword)
POST /employee/_search
{
  "query": {
    "bool": {
      "should": [
        {"term": {
          "dno": {
            "value": 20
          }
        }},
        {"term": {
          "job.keyword": {
            "value": "MANAGER"
          }
        }}
      ]
    }
  }
}