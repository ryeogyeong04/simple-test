-- 02_퀴즈.sql
--  employee를 단일 행 조회해 봅니다.
--  8000 으로 조회합니다.
-- TODO: 1) 전체조회: 문서번호(_id값:8000)
POST /employee/_search
{
  "query": {
    "match_all": {}
  }
}

-- TODO: 2) 문서번호로 조회
GET /employee/_doc/8000