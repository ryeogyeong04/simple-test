-- 퀴즈) job별 급여 평균 구합니다.
-- 위의 결과를 모두 더한 총합도 구하기
-- select avg(salary) from employee
-- group by job
-- TODO: aggs - 별명 - terms : job.keyword(직위별 용어 집계)
-- TODO:               aggs - 별명 - avg: salary(매트릭 집계)
-- TODO:        별명 - sum_bucket - "buckets_path": "부모별명>자식별명"
-- TODO: 자동집계 파이프라인 예약어: sum_bucket(총합), avg_bucket(평균), ...

POST /employee/_search
{
  "size": 0,
  "aggs": {
    "tjob": {
      "terms": {
        "field": "job.keyword"
      },
      "aggs": {
        "asalary": {
          "avg": {
            "field": "salary"
          }
        }
      }
    },
    "tsum": {
      "sum_bucket": {
        "buckets_path": "tjob>asalary"
      }
    }
  }
}