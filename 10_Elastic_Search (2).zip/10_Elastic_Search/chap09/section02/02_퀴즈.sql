-- 퀴즈) emp 인덱스에 여러개 추가하기단, 문서번호는 eno와 동일하게 추가하세요
-- eno, ename, insert_time, update_time
-- TODO: 있으면 수정 없으면 추가
POST /emp/_bulk
{ "index": {"_id":8001} }
{ "eno": 8001, "ename": "ALLEN", "insert_time": "2025-07-30T00:00:00", "update_time": null }
{ "index": {"_id":8002} }
{ "eno": 8002, "ename": "WARD", "insert_time": "2025-07-30T00:00:00", "update_time": null }


POST /emp/_search
{
  "query": {
    "match_all": {}
  }
}