-- 퀴즈) 모든 인덱스의(department, employee) 모든 필드에서 SCOTT 또는 RESEARCH 
-- 가 있는 단어를 찾아서 모두 화면에 표시하세요
-- TODO: POST /인덱스,인덱스2,.../_search
-- TODO: query - multi_match {"query": "검색어","fields": ["*"]}

POST /department,employee/_search
{
  "query": {
    "multi_match": {
      "query": "SCOTT RESEARCH",
      "fields": ["*"]
    }
  }
}