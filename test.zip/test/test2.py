# https://www.saucedemo.com/ 접속 및 로그인후 나오는 첫페이지에서 상품설명을 모두 크롤링해서 화면에 표시하는 코딩을 하세요
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# 브라우저 열기
driver = webdriver.Chrome()

# 사이트 접속
driver.get("https://www.saucedemo.com/")

# 로그인 (기본 제공 계정 사용)
driver.find_element(By.ID, "user-name").send_keys("standard_user")
driver.find_element(By.ID, "password").send_keys("secret_sauce")
driver.find_element(By.ID, "login-button").click()

input("엔터를 누르면 브라우저가 닫힙니다...")
driver.quit()

# 상품 설명 크롤링
descriptions = driver.find_elements(By.CLASS_NAME, "inventory_item_desc")

print("=== 상품 설명 목록 ===")
for idx, desc in enumerate(descriptions, start=1):
    print(f"{idx}. {desc.text}")

# 브라우저 종료
driver.quit()
