-- 01_수정.sql
-- 예제) DEPT 테이블에 데이터를 수정하세요
-- 단, 20번 부서의 부서명을 연구소로 수정하세요
-- TODO: 1) 일부 필드만 수정
-- 기본키(문서번호): 20
POST /department/_search
{
  "query": {
    "match_all": {}
  }
}
-- 문서번호로 일부 필드만 수정
-- TODO: doc - 필드:값
-- 사용법
-- POST /인덱스/_update/기본키(문서번호)
-- {
--   "doc": {
--     "필드":"값"
--     ...
--   }
-- }
POST /department/_update/20
{
  "doc": {
    "dname":"개발부"
  }
}