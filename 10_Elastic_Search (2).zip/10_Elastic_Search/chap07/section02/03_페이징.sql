-- 예제) 부서번호가 10 과 30 사이  조회하고 페이징하세요
-- 단, from(0), size(3) 사용하세요
-- select * from employee
-- where dno between 10 and 30
-- TODO: query - range

POST /employee/_search
{
  "from": 0,
  "size": 3, 
  "query": {
    "range": {
      "dno": {
        "gte": 10,
        "lte": 30
      }
    }
  }
}
