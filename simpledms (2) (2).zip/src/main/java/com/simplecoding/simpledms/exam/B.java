package com.simplecoding.simpledms.exam;

public class B {
}

// 2. 생성자 DI와 컨트롤러를 만들려고 합니다.
// 아래 코드 중 누락된 부분을 추가하세요
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RestController;
//
// @RestController
// public class DeptController {
///        서비스 가져오기
//        private DeptService deptService;
//...

////      생성자 주입
//    @Autowired
//    public DeptController(DeptService deptService) {
//        this.deptService = deptService;

//    }
//}
