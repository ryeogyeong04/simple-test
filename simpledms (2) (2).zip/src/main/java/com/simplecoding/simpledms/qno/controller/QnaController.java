package com.simplecoding.simpledms.qno.controller;


import com.simplecoding.simpledms.qno.dto.QnaDto;
import com.simplecoding.simpledms.qno.service.QnaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class QnaController {
    private final QnaService qnaService;

    @Autowired
    public QnaController(QnaService qnaService) {
        this.qnaService = qnaService;
    }

    @GetMapping("/qna/list")
    public String listQna(Model model) {
        List<QnaDto> qnaList = qnaService.getAllQnas();
        model.addAttribute("qnaList", qnaList);
        return "qna/qnaList"; // JSP 미제출 조건, 경로만 명시
    }
}
