package com.simplecoding.simpledms.exam;

public class A {
//    1)  1. 스프링의 DI, IOC, AOP에 대해서 설명해주세요
//    DI : 클래스 간의 의존 관계를 외부(스프링 컨테이너)에서 주입해주는 방식.
//    IOC : 제어의 흐름을 개발자가 아닌 스프링 프레임워크가 담당하는 구조.
//    AOP : **공통 관심사(로깅, 보안, 트랜잭션 등)**를 핵심 비즈니스 로직과 분리해서 관리하는 기법.

}
