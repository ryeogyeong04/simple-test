-- 예제 1) 사원들의  상여금(commission) 합계, 평균, 최소,최고액을 화면에 표시하세요
-- TODO: 오픈소스 db 사용해봤나? nosql db(엘라스틱, 몽고db)
-- select sum(commission), min(commission)
--        avg(commission), max(commission) from employee
-- TODO: aggs - 별명 - sum
-- TODO:        별명 - avg
POST /employee/_search
{
  "size": 0,
  "aggs": {
    "totalsum": {
      "sum": {
        "field": "commission"
      }
    },
    "totalavg": {
      "avg": {
        "field": "commission"
      }
    },
    "totalmin": {
      "min": {
        "field": "commission"
      }
    },
    "totalmax": {
      "max": {
        "field": "commission"
      }
    }
  }
}

-- 2) 상여금(commission) 에서 30%에 해당하는 급여와 70% 해당하는 급여를 
-- 표시하세요
-- TODO: aggs - 별명 - percentiles
POST /employee/_search
{
  "size": 0,
  "aggs": {
    "pcommission": {
      "percentiles": {
        "field": "commission",
        "percents": [
          30,
          70
        ]
      }
    }
  }
}

-- 예제3) 상여금(commission) 500 단위로 각각 집계해서 표시하세요
-- TODO: 일정숫자 집계: 히스토그램 집계
-- TODO; aggs - 별명 - histogram

POST /employee/_search
{
  "size": 0, 
  "aggs": {
    "hcommission": {
      "histogram": {
        "field": "commission",
        "interval": 500
      }
    }
  }
}