package com.simplecoding.simpledms.qno.service;


import com.simplecoding.simpledms.qno.dto.QnaDto;
import com.simplecoding.simpledms.qno.entity.Qna;
import com.simplecoding.simpledms.qno.repository.QnaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class QnaServiceImpl implements QnaService{
    private final QnaRepository qnaRepository;

    @Autowired
    public QnaServiceImpl(QnaRepository qnaRepository) {
        this.qnaRepository = qnaRepository;
    }

    @Override
    public List<QnaDto> getAllQnas() {
        List<Qna> qnaList = qnaRepository.findAll();
        return qnaList.stream()
                .map(q -> new QnaDto(
                        q.getQnaId(),
                        q.getTitle(),
                        q.getWriter(),
                        q.getRegDate()))
                .collect(Collectors.toList());
    }
}
