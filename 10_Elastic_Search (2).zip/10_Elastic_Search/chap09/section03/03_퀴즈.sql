-- 퀴즈) employee 첫번째 문서 여러 데이터 데체하기
-- 사용법
-- PUT /인덱스/_doc/기본키(문서번호)
-- {
--   "필드": 값,
--   ...
-- }

-- 1) 8002
POST /employee/_search
{
  "from": 0,
  "size": 20, 
  "query": {
    "match_all": {}
  }
}

PUT /employee/_doc/8002
{
  "eno": 8002,
  "ename": "스미스",
  "job": "부장" 
}
