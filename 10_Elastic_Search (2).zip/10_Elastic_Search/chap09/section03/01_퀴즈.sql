-- 퀴즈) emp 첫번째 문서 데이터 수정하기
-- TODO: doc - 필드:값
-- 사용법
-- POST /인덱스/_update/기본키(문서번호)
-- {
--   "doc": {
--     "필드":"값"
--     ...
--   }
-- }
-- 기본키(문서번호): 8000
-- TODO: from(오프셋), size(기본 10): 20 으로 변경
POST /employee/_search
{
  "from": 0,
  "size": 20, 
  "query": {
    "match_all": {}
  }
}
-- TODO: doc - 필드:값
POST /employee/_update/8000
{
  "doc": {
    "ename": "홍길동"
  }
}