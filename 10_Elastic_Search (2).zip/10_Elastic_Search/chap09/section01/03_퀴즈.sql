-- 퀴즈) edx-emp 삭제하세요
-- TODO: 사용법: DELETE /인덱스명
DELETE /edx-emp
