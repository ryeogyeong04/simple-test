-- 예제) dept 첫번째 문서 전체 필드 대체하기
-- TODO: 기존에 있는 문서 필드는 모두 삭제되고 새로 만들어집니다
-- TODO: nosql 특징: 비정형(형태가 들쭉날쭉한 것) 데이터를 저장(nosql db)
-- TODO:             정형(형태가 일정한) 데이터(오라클)

POST /department/_search
{
  "query": {
    "match_all": {}
  }
}

-- 전체수정: 문서번호 선택
-- 사용법
-- PUT /인덱스/_doc/기본키(문서번호)
-- {
--   "필드": 값,
--   ...
-- }
PUT /department/_doc/10
{
  "dno": 10,
  "dname": "개발부2"
}
