-- 퀴즈) ALLEN 사원보다 급여를(SALARY) 많이 받는 사원이 누구인지 표시하세요
-- 1) select salary from employee
--    where ename='ALLEN'
-- TODO; 정확일치: query - term
-- 답: 1600
POST /employee/_search
{
  "query": {
    "term": {
      "ename.keyword": {
        "value": "ALLEN"
      }
    }
  }
}


-- TODO: query - term(=): 글자필드.keyword, 숫자필드
-- 2) 1600 보다 많이 받는 사원
-- select * from employee
-- where salary > 1600
-- TODO: query - range(> , < 등)

POST /employee/_search
{
  "query": {
    "range": {
      "salary": {
        "gt": 1600
      }
    }
  }
}