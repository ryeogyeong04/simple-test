-- 퀴즈 1) KING 사원을 조회하세요, 단 match(전문 검색, 자연어검색)을 이용하세요
-- select * from employee
-- where ename='KING'
POST /employee/_search
{
  "query": {
    "match": {
      "ename": "KING"
    }
  }
}

-- 퀴즈 2) job 이 "SALESMAN" 인 사원을 조회하세요, 단 match(전문 검색, 자연어검색)을 
-- 이용하세요
-- select * from employee
-- where job='SALESMAN'
POST /employee/_search
{
  "query": {
    "match": {
      "job": "SALESMAN"
    }
  }
}

-- 퀴즈3) dname 이 "RESEARCH" 인 부서를 조회하세요, 단 match(전문 검색, 자연어검색)
-- 을 이용하세요
-- select * from department
-- where dname ='RESEARCH'

POST /department/_search
{
  "query": {
    "match": {
      "dname": "RESEARCH"
    }
  }
}

