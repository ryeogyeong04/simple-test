-- 퀴즈) EMP 테이블을 만드세요.
-- 단, EMPLOYEE 테이블 컬럼 정보를 확인하고 똑같이 만드세요
-- TODO: 매핑 정보 확인 사용법: GET /인덱스/_mapping
-- TODO: mappings - properties(eno, ename, insert_time, update_time)

PUT /emp
{
  "mappings": {
    "properties": {
      "eno": {"type": "integer"},
      "ename": {
        "type": "text",
        "fields": {"keyword": {"type": "keyword"}}
      },
      "insert_time": {
        "type": "date"
      },
      "update_time": {
        "type": "date"
      }
    }
  }
}

-- 확인
GET /emp/_mapping