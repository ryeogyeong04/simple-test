# 키바나의 차트 기능 훝어보기
# 01_Data_View.md
# 햄거버메뉴 - Discover - Create Data View 클릭
# Create Data View 화면
#              1) Name           : employee
#              2) Index patterm  : employee
#              3) Timestamp field: hiredate
# 화면전환: View All Match 클릭 -> 차트+데이터 나옴
# 오른쪽 날짜글자:시작~끝 달력조정 가능 -> 그래프 다시 나옴