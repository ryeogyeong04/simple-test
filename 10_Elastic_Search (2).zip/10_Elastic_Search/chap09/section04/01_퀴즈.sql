-- 퀴즈) emp 데이터를 삭제하세요
-- 단, 8000번 사원을 삭제하세요
-- TODO: 사용법:  DELETE /인덱스/_doc/기본키(문서번호)
POST /emp/_search
{
  "query": {
    "match_all": {}
  }
}


DELETE /emp/_doc/8001

-- 퀴즈) emp 인덱스도 삭제하세요
-- TODO: 사용법:  DELETE /인덱스
DELETE /emp