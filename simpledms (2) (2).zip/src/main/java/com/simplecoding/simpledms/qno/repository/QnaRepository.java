package com.simplecoding.simpledms.qno.repository;

import com.simplecoding.simpledms.qno.entity.Qna;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QnaRepository extends JpaRepository<Qna, Long> {
}
