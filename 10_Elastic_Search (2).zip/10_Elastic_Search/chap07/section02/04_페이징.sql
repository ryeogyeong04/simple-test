-- 예제) 부서번호가 10 과 20 사이 속하지 않는 사원를 페이징 하세요
-- TODO: from, size
-- TODO: not: query - bool - must_not - range
-- select * from employee
-- where dno not between 10 and 20

POST /employee/_search
{
  "from": 0,
  "size": 3, 
  "query": {
    "bool": {
      "must_not": [
        {
          "range": {
            "dno": {
              "gte": 10,
              "lte": 20
            }
          }
        }
      ]
    }
  }
}