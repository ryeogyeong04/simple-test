-- 퀴즈) 사원들의 급여(SALARY) 평균(avg), 최소액(min)을 화면에 표시하세요
-- select avg(salary) as tavg, min(salary) as tmin from employee
-- TODO: aggs - 별명 - sum - field:필드명
POST /employee/_search
{
  "size": 0, 
  "aggs": {
    "tavg": {
      "avg": {
        "field": "salary"
      }
    },
    "tmin": {
      "min": {
        "field": "salary"
      }
    }
  }
}