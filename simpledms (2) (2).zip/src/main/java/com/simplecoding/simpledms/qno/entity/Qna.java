package com.simplecoding.simpledms.qno.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

    @Entity
    @Table(name = "TB_QNA")
    public class Qna {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long qnaId;

        private String title;
        private String content;
        private String writer;
        private LocalDateTime regDate;

        // Getters and Setters
        public Long getQnaId() { return qnaId; }
        public void setQnaId(Long qnaId) { this.qnaId = qnaId; }

        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }

        public String getContent() { return content; }
        public void setContent(String content) { this.content = content; }

        public String getWriter() { return writer; }
        public void setWriter(String writer) { this.writer = writer; }

        public LocalDateTime getRegDate() { return regDate; }
        public void setRegDate(LocalDateTime regDate) { this.regDate = regDate; }
    }

