-- 퀴즈) emp 첫번째 문서 여러 데이터 수정하기
-- TODO: doc - 필드:값, 필드2:값2, ...
-- TODO: ename(스미스), job(부장) 변경
-- 사용법
-- POST /인덱스/_update/기본키(문서번호)
-- {
--   "doc": {
--     "필드":"값"
--     "필드2":"값2"
--     ...
--   }
-- }
POST /employee/_search
{
  "from": 0,
  "size": 20, 
  "query": {
    "match_all": {}
  }
}

POST /employee/_update/8001
{
  "doc": {
    "ename": "스미스",
    "job": "부장"
  }
}