-- 1) 급여가(SALARY) 2000을 넘는 사원의 이름과(ENAME) 급여를 
-- 급여가 많은 것부터 작은 순으로 출력하세요(내림차순)
-- select * from employee
-- where salary > 2000
-- order by salary desc
-- 복잡한 조회: POST 
-- 간단 조회: GET
-- TODO: query - range(>,< 등)
-- TODO: gte(>=), gt(>), lte(<=), lt(<)
POST /employee/_search
{
  "query": {
    "range": {
      "salary": {
        "gt": 2000
      }
    }
  },
  "sort": [
    {
      "salary": {
        "order": "desc"
      }
    }
  ]
}

-- 2) 사원번호가(ENO) 8000 인 사원의 이름과(ENAME) 
-- 부서번호를(DNO) 표시하세요
-- select ename,dno from employee
-- where eno=8000
-- 정확비교: term(=)
-- 범위비교: range(>,<)
-- TODO: query - term
POST /employee/_search
{
  "_source": ["ename", "dno"], 
  "query": {
    "term": {
      "eno": {
        "value": 8000
      }
    }
  }
}

-- 3) 급여가(SALARY) 2000에서 3000 사이에 포함되지 않는 
-- 사원의 이름과(ENAME) 급여를 표시하세요
-- select ename, salary from employee
-- where not (salary >= 2000 and salary <= 3000)
-- TODO: query - bool - must_not
-- TODO: term(=, 일치), range(>=, <=, >,<)
-- TODO: gte(>=), gt(>), lte(<=), lt(<)
POST /employee/_search
{
  "_source": ["ename", "salary"], 
  "query": {
    "bool": {
      "must_not": [
        {
          "range": {
            "salary": {
              "gte": 2000,
              "lte": 3000
            }
          }
        }
      ]
    }
  }
}

-- 4) 1981년 2월 20일 부터 1981년 5월 1일 사이에 입사한 사원의 
-- 이름(ENAME), 직위(JOB), 입사일(HIREDATE)을 표시하세요
-- select * from employee
-- where hiredate between '1981-02-20' and '1981-05-01'
-- TODO: query - range 
-- TODO: gte(>=), gt(>), lte(<=), lt(<)
POST /employee/_search
{
  "query": {
    "range": {
      "hiredate": {
        "gte": "1981-02-20",
        "lte": "1981-05-01"
      }
    }
  }
}