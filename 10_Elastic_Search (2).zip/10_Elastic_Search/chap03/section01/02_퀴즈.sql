-- 퀴즈) 1) 사원명(ENAME) 이 ALLEN 인 사원의 정보를 출력하세요
-- select * from employee 
-- where ename = 'ALLEN'
-- query - term - 필드.keyword
POST /employee/_search
{
  "query": {
    "term": {
      "ename.keyword": {
        "value": "ALLEN"
      }
    }
  }
}

-- 퀴즈) 2) JOB(직위) 이 CLERK 인 사원을 출력하세요
-- select * from employee
-- where job='CLERK'
-- query - term - 필드.keyword
POST /employee/_search
{
  "query": {
    "term": {
      "job.keyword": {
        "value": "CLERK"
      }
    }
  }
}