-- 예제) idx-dept 삭제하세요
-- TODO: 사용법: DELETE /인덱스명
DELETE /idx-dept